
<html>

#Hospital_structure
#========================

id
name
description
image-multiple image silde
country_code + phone
country_code + mobile
address- auto complete 
street
apartment
city
state
country
address_lat
address_long
social link(facebook, instagram, twitter, dribble)
start_day
end_day
working_day(full param for start to end)
start_time
end_time
services (multiple ids)
status
checkbox sinlglee for offer applier or not (if checked then insert price after discount)
created_at
updated_at


Service structure
======================

id
name
price_before_discount(default price 0)
price_after_discount(default price 0)

Multiple Image structure
==========================

id 
image
hospital_id

</html>



