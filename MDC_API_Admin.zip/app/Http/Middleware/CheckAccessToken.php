<?php

namespace App\Http\Middleware;

use DB;
use Closure;


class CheckAccessToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $apikey = $request->header('apikey');
        $user_id = $request->header('userid');
        $access_token = $request->header('accesstoken');

        if($apikey == "")
        {
            return response()->json(["status" => 0, "message" => "The apikey field is required."]);
        }

        if($user_id == "")
        {
            return response()->json(["status" => 0, "message" => "The userid field is required."]);
        }

        if($access_token == "")
        {
            return response()->json(["status" => 0, "message" => "The accessToken field is required."]);
        }

        //$apidata = Access_tokens::where('apikey', $apikey)->where('user_role', $user_role)->first();
        $access = DB::table('access_tokens')
            ->join('apikeys', 'apikeys.id', '=', 'access_tokens.apikey_id')
            ->where('apikeys.apikey', $apikey)
            ->where('access_tokens.access_token', $access_token)
            ->where('access_tokens.user_id', $user_id)
            ->select('apikeys.*', 'access_tokens.*')
            ->first();

        if (!$access) {
            return response()->json(["status" => 0, "message" => "Invalid access token."]);
        }

        return $next($request);
    }
}
