<?php

namespace App\Objects;

use Illuminate\Database\Eloquent\Model;

class HospitalImages extends Model
{
    protected $table = 'hospital_images';
}
