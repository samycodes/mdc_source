<?php

namespace App\Objects;

use Illuminate\Database\Eloquent\Model;

class DocumentType extends Model
{
    protected $table = 'card_document_type';
}
