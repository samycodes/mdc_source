<?php

namespace App\Objects;

use Illuminate\Database\Eloquent\Model;

class APIKey extends Model
{
    protected $table = 'api_keys';
}
