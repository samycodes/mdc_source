<?php

namespace App\Objects;

use Illuminate\Database\Eloquent\Model;

class Services extends Model
{
    protected $table = 'services';
}
