<?php

namespace App\Objects;

use Illuminate\Database\Eloquent\Model;

class CardType extends Model
{
    protected $table = 'card_type';
}
