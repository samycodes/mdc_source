<?php
namespace App\Objects;

use Illuminate\Database\Eloquent\Model;

class Aboutus extends Model
{

    protected $table = 'about_us';

    
}
